export const getIndex = (req, res) => {
    res.send('Hola mundo desde API');
}

export const getPong = (req, res) => {
    res.send('pong');
}